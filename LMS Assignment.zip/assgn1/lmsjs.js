function evenalert()
{
alert("About Us:\n This is our pilot project to develop a framework of virtual repository of learning resources with a single-window search facility. Filtered and federated searching is employed to facilitate focused searching so that learners can find out the right resource with least effort and in minimum time.We offer traditional publishing contracts and bespoke shared partnership contracts and are more than happy to discuss both options with interested persons.We provide free service that helps millions of readers discover books they'll love. Upon joining, members receive unbeatable deals selected by our expert editorial team, handpicked recommendations from people they trust, and real-time updates from their favorite authors. ");
}
function evenalert2()
{
alert("Contact Us on :\n Digital Library  Project\nCentral Library (ISO-9001:2015 Certified)\nPhone: +91-3222-282435\nFor any issue or feedback, please write to lbg-support@gmail.com\n Map URL:https://goo.gl/maps/sEHeZ14NvEgYKUKJ7");
}
function evenalert3()
{
alert("Support US by valuable donations:\n The project is supported by user donations. Imagine the world with free access to knowledge for everyone ‐ a world without any paywalls. Donate for this vision to become true. Make your contribution to the battle against copyright laws and information inequality. Even the smallest donation counts.\nSend you contribution to the Bitcoin address:\n 12PCbUDS4ho7vgSccmixKTHmq9uuiopL2mdSns")
}